<?php
// Kết thúc nội dung và các thẻ HTML
echo "<footer>";
echo "    <hr>";
echo "    <p>&copy; " . date("Y") . " Bản quyền thuộc về [Tên của bạn].</p>";
echo "</footer>";
echo "</body>";
echo "</html>";
?>