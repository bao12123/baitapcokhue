<?php
include 'header.php';
// --- Nội dung Chính của trang Home ---
echo "<h2>Chào mừng đến với trang chủ!</h2>";
echo "<p>Đây là nội dung độc lập của file home.php.</p>";
echo "<p>Cả tiêu đề (header) và chân trang (footer) đều được chèn tự động.</p>";
// 2. Include footer
include 'footer.php';
?>