<?php
// Bắt đầu HTML, head, và body
echo "<!DOCTYPE html>";
echo "<html>";
echo "<head>";
echo "    <title>Trang Chủ - Website</title>";
echo "    <meta charset='UTF-8'>";
echo "    <style>body { font-family: Arial; margin: 0; padding: 20px; } header { background-color: #f0f0f0; padding: 10px; border-bottom: 2px solid #ccc; }</style>";
echo "</head>";
echo "<body>";
echo "<header>";
echo "    <h1>Website Chính Thức Của Tôi</h1>";
echo "</header>";
?>